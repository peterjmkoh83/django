from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import *


def index(request):
     show = Show.objects.all() 
     
     context = {
          "all_shows": show
     }
     return render(request, "shows/index.html", context)

def new_show(request):
     return render(request, "shows/new_show.html")

def add(request):
     errors = Show.objects.basic_validator(request.POST)

     if len(errors) > 0:
          for key, value in errors.items():
               messages.error(request, value)
          return redirect("/shows/new")
     else:
          new_show = Show.objects.create(title=request.POST["title"], network=request.POST["network"], release_date=request.POST["release_date"], description=request.POST["description"])
          show_id = new_show.id
          messages.success(request, "Show successfully updated")
          return redirect("/shows/" + str(show_id))

def info_show(request, id):
     show = Show.objects.get(id=id)
     context = {
          "show_info": show
     }
     return render(request, "shows/info_show.html", context)

def edit_show(request, id):
     edit = Show.objects.get(id=id)
     context = {
          "edit_info": edit
     }
     return render(request, "shows/edit_show.html", context)

def update(request, id):
     update = Show.objects.get(id=id)
     
     update.title = request.POST["title"]
     update.network = request.POST["network"]
     update.release_date = request.POST["release_date"]
     update.description = request.POST["description"]
     update.save()
     
     return redirect("/shows/" + str(id))

def delete(request, id):
     delete = Show.objects.get(id=id)
     delete.delete()

     return redirect("/shows")


     
