from django.conf.urls import url
from . import views

urlpatterns = [
     url(r'^shows$', views.index),
     url(r'^shows/new$', views.new_show),
     url(r'^add$', views.add),
     url(r'^shows/(?P<id>[0-9]+)$', views.info_show),
     url(r'^shows/(?P<id>[0-9]+)/edit$', views.edit_show),
     url(r'^update/(?P<id>[0-9]+)$', views.update),
     url(r'^delete/(?P<id>[0-9]+)$', views.delete),
]
