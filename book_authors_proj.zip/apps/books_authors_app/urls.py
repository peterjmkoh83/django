from django.conf.urls import url
from . import views

urlpatterns = [
     url(r'^$', views.index),
     url(r'^add$', views.add),
     url(r'^books/(?P<id>\d+)$', views.books_detail),
     url(r'^authors$', views.authors),
     url(r'^add_author$', views.add_author),
     url(r'^authors/(?P<id>\d+)$', views.authors_detail),
     
]