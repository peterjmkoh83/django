from django.shortcuts import render, HttpResponse, redirect
from .models import *

def index(request): 
     context = {
          "all_books" : Book.objects.all(),
     }
     return render(request, "books_authors_app/index.html", context)

def add(request):
     Book.objects.create(title=request.POST["title"], desc=request.POST["desc"])
     return redirect("/")

def books_detail(request, id):
     if request.method == "GET":
          book = Book.objects.get(id=id)
          author = Author.objects.get(id=id)
          context = {     
               "book_id" : book,
               "assigned_authors" : book.authors.all(),
               "all_authors" : Author.objects.all(),
          }
          return render(request, "books_authors_app/books_detail.html", context)
     
     if request.method == "POST":
          book_id = id
          add_author_id = request.POST["author_name"]

          book = Book.objects.get(id = book_id)
          author = Author.objects.get(id = add_author_id)
          book.authors.add(author)
          return redirect(f"/books/{ id }")                  
     
def authors(request):
     context = {
          "all_authors" : Author.objects.all()
     }
     return render(request, "books_authors_app/authors.html", context)

def add_author(request):
     Author.objects.create(first_name=request.POST["fname"], last_name=request.POST["lname"], notes=request.POST["note"])
     return redirect("/authors")

def authors_detail(request, id):
     if request.method == "GET":
          book = Book.objects.get(id=id)
          author = Author.objects.get(id=id)
          context = {     
               "author_id" : author,
               "assigned_books" : author.books.all(),
               "all_books" : Book.objects.all(),
          }
          return render(request, "books_authors_app/authors_detail.html", context)
     
     if request.method == "POST":
          author_id = id
          add_book_id = request.POST["book_name"]

          author = Author.objects.get(id = author_id)
          book = Book.objects.get(id = add_book_id)
          author.books.add(book)
          return redirect(f"/authors/{ id }")
          
         