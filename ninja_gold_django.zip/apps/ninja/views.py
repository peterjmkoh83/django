from django.shortcuts import render, HttpResponse, redirect
import random
from datetime import datetime

def index(request):
     
     if "total_gold" not in request.session:
          request.session["total_gold"] = 0
     if "activities" not in request.session:
          request.session["activities"] = []
     return render(request, "ninja/index.html")

def process(request):
     if request.method == "POST":
          if request.POST["building"] == "farm":
               gold = random.randint(10,21)
               request.session['activities'].append("Earned " + str(gold) + " golds from farm.")

          if request.POST["building"] == "cave":
               gold = random.randint(5,11)
               request.session['activities'].append("Earned " + str(gold) + " golds from farm.")

          if request.POST["building"] == "house":
               gold = random.randint(2,6)
               request.session['activities'].append("Earned " + str(gold) + " golds from farm.")
          
          if request.POST["building"] == "casino":
               gold = random.randint(-50,51)
               request.session['activities'].append("Earned " + str(gold) + " golds from farm.")

          request.session["total_gold"] += gold
     return redirect("/")


def reset(request):
     request.session.clear()
     return redirect("/")
