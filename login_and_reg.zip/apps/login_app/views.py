from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import *

# Registration page
def index(request):
     return render(request, "login_app/index.html")

# Create a user
def create_user(request):
     errors = User.objects.validator(request.POST)
     if len(errors) > 0:
          for key, value in errors.items():
               messages.error(request, value)
          return redirect("/")
     else:
          hashed_pw = bcrypt.hashpw(request.POST["pw"].encode(), bcrypt.gensalt())
          User.objects.create(first_name=request.POST["fn"], last_name=request.POST["ln"], email=request.POST["em"], password=hashed_pw)
          return redirect("/success")

# Log in
def log_in_user(request):
     try: 
          User.objects.get(email=request.POST["email"])
     except:
          messages.error(request, "Invalid user")
          return redirect("/")
     user_pw = User.objects.get(email=request.POST["email"])
     if bcrypt.checkpw(request.POST["password"].encode(), user_pw.password.encode()):
          request.session["user_id"] = user_pw.id
          return redirect("/success")
     else:
          messages.error(request, "Incorrect password")
          return redirect("/")
     
    

# Success page
def success_user(request):
     if not "user_id" in request.session:
          return redirect("/")
     
     context = {
          "user": User.objects.get(id=request.session["user_id"])
     }
     return render(request, "login_app/success.html", context)

# Log out
def log_out_user(request):
     request.session["user_id"].clear()
     return redirect("/")