from __future__ import unicode_literals
from django.db import models
import re
import bcrypt



class UserManager(models.Manager):
     def validator(self, postData):
          # dataemail = User.objects.get(email=postData["em"]) == is_valid
          # is_valid = True
          errors = {}
          EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
          if len(postData["fn"]) < 2:
               errors["fn"] = "First name should be at least 2 characters"
          if len(postData["ln"]) < 2:
               errors["ln"] = "Last name should be at least 2 characters"
          if not EMAIL_REGEX.match(postData["em"]):
               errors["em"] = "Invalid email address!"
          # if dataemail > 0:
          #      errors["em"] = "Email exist already! Please choose another email" 
          if len(postData["pw"]) < 8:
               errors["pw"] = "Password should be at least 8 characters"
          if postData["pw"] != postData["pw_re"]:
               errors["pw_re"] = "Password should match"
          
          return errors
          
          



class User(models.Model):
     first_name = models.CharField(max_length=255)
     last_name = models.CharField(max_length=255)
     email = models.CharField(max_length=255)
     password = models.CharField(max_length=255)
     created_at = models.DateTimeField(auto_now_add=True)
     updated_at = models.DateTimeField(auto_now=True)
     objects = UserManager()

     def __repr__(self):
          return f"{self.first_name} {self.last_name} {self.email} {self.password}"