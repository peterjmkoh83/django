from django.shortcuts import render, HttpResponse, redirect   
import random

def index(request):
    return render(request, "first_app/index.html")

def random_word(request):
     if 'counter' in request.session:
          request.session['counter'] += 1
     else:
          request.session['counter'] = 1 
        
     word = ""
     my_letter = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n"]
     
     for i in range(14):
          word = word + str(random.choice(my_letter))
          words = { 
               "random_word": word
          }
     return render(request, "first_app/index.html", words)

def reset(request):
     request.session.clear()
     return redirect("/")    
     
    
     
     
     
  
     
   
